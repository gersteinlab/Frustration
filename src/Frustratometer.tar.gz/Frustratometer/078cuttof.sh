#!/bin/bash

FRUST_HOME=`dirname "$0"`

awk '($1!= "" && $4>=0.78 && $9!=3){print $1"\t"$2"\tgreen\tsolid\t1\tmin_frst"}' ${1}_cont > ${1}_cont_gt1
awk '($1!= "" && $4>=0.78 && $9==3){print $1"\t"$2"\tgreen\tdashed\t1\tmin_frst"}' ${1}_cont > ${1}_cont_gt1_w
awk '($1!= "" && $4<=-1 && $9==3){print $1"\t"$2"\tred\tdashed\t2\tmax_frst"}' ${1}_cont > ${1}_cont_lt-1_w
awk '($1!= "" && $4<=-1 && $9!=3){print $1"\t"$2"\tred\tsolid\t2\tmax_frst"}' ${1}_cont > ${1}_cont_lt-1
#awk '($1!= "" && $4>-1 && $4<0.78 && $9==3){print $1"\t"$2"\tyellow\tdashed"}' ${1}_cont > cont_gt-1lt1_w
#awk '($1!= "" && $4>-1 && $4<0.78 && $9!=3){print $1"\t"$2"\tyellow\tsolid"}' ${1}_cont > cont_gt-1lt1
cat ${1}_cont_lt-1* ${1}_cont_gt1* >  ${1}_minmax.dat

#Renumber minmax file to get the correct equivalences between original pdb and frustratometer files.
perl $FRUST_HOME/AuxiliarScripts/renumber_frst_files.pl ${1} ${1}_equivalences.txt $2

$FRUST_HOME/run_vmdline.sh ${1}_minmax.dat > ${1}_mfrst.tclr
$FRUST_HOME/run_jmolline.sh ${1}_minmax.dat > ${1}_mfrst.jmolr
$FRUST_HOME/run_pymolline.sh ${1}_minmax.dat > ${1}_mfrst.pmlr

$FRUST_HOME/run_vmdline_renum.sh ${1}_minmax_renum.dat > ${1}_renum_mfrst.tclr
$FRUST_HOME/run_jmolline_renum.sh ${1}_minmax_renum.dat > ${1}_renum_mfrst.jmolr
$FRUST_HOME/run_pymolline_renum.sh ${1}_minmax_renum.dat > ${1}_renum_mfrst.pmlr

echo "mut_cont"

awk '($1!= "" && $3>=0.78 && $9!=3){print $1"\t"$2"\tgreen\tsolid\t1\tmin_frst"}' ${1}_cont > ${1}_cont_gt1
awk '($1!= "" && $3>=0.78 && $9==3){print $1"\t"$2"\tgreen\tdashed\t1\tmin_frst"}' ${1}_cont > ${1}_cont_gt1_w
awk '($1!= "" && $3<=-1 && $9==3){print $1"\t"$2"\tred\tdashed\t2\tmax_frst"}' ${1}_cont > ${1}_cont_lt-1_w
awk '($1!= "" && $3<=-1 && $9!=3){print $1"\t"$2"\tred\tsolid\t2\tmax_frst"}' ${1}_cont > ${1}_cont_lt-1
#awk '($1!= "" && $3>-1 && $3<0.78 && $9==3){print $1"\t"$2"\tyellow\tdashed"}' ${1}_cont > cont_gt-1lt1_w
#awk '($1!= "" && $3>-1 && $3<0.78 && $9!=3){print $1"\t"$2"\tyellow\tsolid"}' ${1}_cont > cont_gt-1lt1
cat ${1}_cont_lt-1* ${1}_cont_gt1* >  ${1}_minmax.dat

#Renumber minmax file to get the correct equivalences between original pdb and frustratometer files.
perl $FRUST_HOME/AuxiliarScripts/renumber_frst_files.pl ${1} ${1}_equivalences.txt $2

$FRUST_HOME/run_vmdline.sh ${1}_minmax.dat > ${1}_cfrst.tclr
$FRUST_HOME/run_jmolline.sh ${1}_minmax.dat > ${1}_cfrst.jmolr
$FRUST_HOME/run_pymolline.sh ${1}_minmax.dat > ${1}_cfrst.pmlr

$FRUST_HOME/run_vmdline_renum.sh ${1}_minmax_renum.dat > ${1}_renum_cfrst.tclr
$FRUST_HOME/run_jmolline_renum.sh ${1}_minmax_renum.dat > ${1}_renum_cfrst.jmolr
$FRUST_HOME/run_pymolline_renum.sh ${1}_minmax_renum.dat > ${1}_renum_cfrst.pmlr

rm ${1}_cont_gt* ${1}_cont_lt*  ${1}_minmax.dat
echo "conf_cont"

cat << EOF > ${1}_colorit.tclr
mol modselect 0 top "all"
mol modstyle 0 top newcartoon
mol modcolor 0 top colorid 15
EOF

cat << EOF > ${1}_colorit.jmolr
select protein; cartoons;
connect delete;
spacefill off;
color background white;
EOF

cat << EOF > ${1}_colorit.pmlr
load ${2}
hide all
show cartoon, all
color grey, all
run draw_links.py
EOF

cat << EOF > ${1}_colorit_end.pmlr
zoom all
hide labels
color red, max_frst_wm
color green, min_frst_wm
EOF

#renumbered pml
cat << EOF > ${1}_renum_colorit.pmlr
load ${2}
hide all
show cartoon, all
color grey, all
run draw_links.py
EOF

cat << EOF > ${1}_renum_colorit_end.pmlr
zoom all
hide labels
color red, max_frst_wm
color green, min_frst_wm
EOF

#renumbered tcl
cat << EOF > ${1}_renum_colorit.tclr
mol modselect 0 top "all"
mol modstyle 0 top newcartoon
mol modcolor 0 top colorid 15
EOF

#renumbered jmol
cat << EOF > ${1}_renum_colorit.jmolr
select protein; cartoons;
connect delete;
spacefill off;
color background white;
EOF

#----------------------------
#Termino de modificar los scripts
cat ${1}_colorit.jmolr ${1}_cfrst.jmolr  > ${1}_cfrst.jmol
cat ${1}_colorit.jmolr ${1}_mfrst.jmolr  > ${1}_mfrst.jmol
cat ${1}_cfrst.tclr ${1}_colorit.tclr  > ${1}_cfrst.tcl
cat ${1}_mfrst.tclr ${1}_colorit.tclr  > ${1}_mfrst.tcl
cat ${1}_colorit.pmlr ${1}_cfrst.pmlr ${1}_colorit_end.pmlr > ${1}_cfrst.pml
cat ${1}_colorit.pmlr ${1}_mfrst.pmlr ${1}_colorit_end.pmlr > ${1}_mfrst.pml

#renumbered
cat ${1}_renum_colorit.pmlr ${1}_renum_cfrst.pmlr ${1}_renum_colorit_end.pmlr > ${1}_renum_cfrst.pml
cat ${1}_renum_colorit.pmlr ${1}_renum_mfrst.pmlr ${1}_renum_colorit_end.pmlr > ${1}_renum_mfrst.pml
cat ${1}_renum_cfrst.tclr ${1}_renum_colorit.tclr  > ${1}_renum_cfrst.tcl
cat ${1}_renum_mfrst.tclr ${1}_renum_colorit.tclr  > ${1}_renum_mfrst.tcl
cat ${1}_renum_colorit.jmolr ${1}_renum_cfrst.jmolr  > ${1}_renum_cfrst.jmol
cat ${1}_renum_colorit.jmolr ${1}_renum_mfrst.jmolr  > ${1}_renum_mfrst.jmol

rm  ${1}*.tclr ${1}*.jmolr ${1}*.pmlr

echo "done"
