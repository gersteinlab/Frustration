#!/bin/bash
X=1
Z=0
L="$(grep -c "" $1)"
while [ $X -le $L ]
do
        Y=$((Z+1))
								#grep -n "" $1 | awk -F ":" '($1=='$X'){print $2}' | awk '{ print $4=="solid"?"draw_links resi "$1" and name CA, resi "$2" and name CA, color="$3", color2="$3", radius=0.05, object_name="$3"_solid":$3=="green"?"distance green_wm= (resi "$1" and name CA), (resi "$2" and name CA)":"red_wm= (resi "$1" and name CA), (resi "$2" and name CA)" }'
								grep -n "" $1 | awk -F ":" '($1=='$X'){print $2}' | awk '{ print $4=="solid"?"draw_links resi "1+$1" and name CA, resi "1+$2" and name CA, color="$3", color2="$3", radius=0.05, object_name="1+$1":"1+$2"_"$6"":$3=="green"?"distance min_frst_wm= (resi "1+$1" and name CA), (resi "1+$2" and name CA)":"distance max_frst_wm= (resi "1+$1" and name CA), (resi "1+$2" and name CA)" }'    
#        grep -n "" $1 | awk -F ":" '($1=='$X'){print $2}' | awk '{ print "select "1+$1".CA, "1+$2".CA;\nCONNECT single; CONNECT "$3" ",$4=="solid"?"single":"translucent"," radius 0."$5";"}' 

	Z=$((Z+2))
        X=$((X+1))
done
