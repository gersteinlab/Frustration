#usage perl PdbFile Chain

open (PDBMODEL,"$ARGV[0]");
my @opened_model = (); 
@opened_model=<PDBMODEL>; 
close (PDBMODEL);

my @ATOMS=qx(awk '{if (\$1=="ATOM") print } ' $ARGV[0]);
my @line1=split ("", $ATOMS[1]);

if ($line1[21] eq " ")
{
open(SALIDA, ">$ARGV[0]") || die "ERROR: No puedo abrir el fichero $salida\n";

my $chain=$ARGV[1];


for my $i ( 0 .. $#opened_model) {

    if($opened_model[$i]=~/^ATOM/)
    {
      my @line2=split ("", $opened_model[$i]);
      $line2[21]=$chain;
      print SALIDA @line2;
    }
}
}
