#usage perl RemoveTerminalGlys.pl PdbFile
my $PDB=$ARGV[0];

$n_gly=1;

my @CAs=qx(grep \"CA  \\w[a-zA-Z]\" $PDB);


my $last=substr($CAs[-$n_gly], 17, 3);

while($last eq "GLY")
{
		my $RES= substr($CAs[-$n_gly], 22, 4),"\n";
		system ("awk -F '' '{if (\$23\$24\$25\$26 != \"$RES\") print } ' $PDB > Gly_removed");
		system ("rm $PDB");
		system ("mv Gly_removed $PDB");

		$n_gly++;
		$last=substr($CAs[-$n_gly], 17, 3);
}

