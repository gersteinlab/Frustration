#!/usr/local/bin/perl
use strict;

print "$ARGV[1]\n";

open (SALIDA, ">$ARGV[1]/$ARGV[0]_equivalences.txt");


my %Chains=();
my @Residues= qx(awk '{print}' $ARGV[0]);

my $aux="";

my $eq=0;


#get chains
my $aux_chain='1';
foreach my $line (@Residues)
{
			if(substr($line, 0,4) eq "ATOM")
			{
				my $chain=substr($line, 21,1);
				if ($chain ne $aux_chain)
				{
						$Chains{$chain}=1;
				}
			$aux_chain=$chain;
	}
}

while(my ($single_chain, $value) = each %Chains)
{
 my @Residues= qx(awk ' {FS=""} { if (\$1\$2\$3\$4=="ATOM" && \$22=="$single_chain") print }' $ARGV[0]);

for(my $i=0; $i<@Residues; $i++)
{
			if(substr($Residues[$i], 0,4) eq "ATOM")
			{
				my $res=substr($Residues[$i], 22, 5);
				my $chain=substr($Residues[$i], 21, 1);
				my $insertion=substr($Residues[$i], 23, 1);

				$res =~ s/\s+$//;

				if($res ne $aux)	
				{
					if($eq<10){$eq="   ".$eq;} elsif($eq<100){$eq="  ".$eq;}elsif($eq<1000){$eq=" ".$eq;}
					print SALIDA "$chain$eq$res\n";
					$eq++;
				}
				$aux=$res;
		}
}


}

close SALIDA;
