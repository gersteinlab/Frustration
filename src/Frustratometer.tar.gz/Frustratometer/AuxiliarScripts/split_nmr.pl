
my $model_beg=qx(grep '^MODEL' $ARGV[0] | wc -l);
my $model_end=qx(grep '^ENDMDL' $ARGV[0] | wc -l);

if($model_beg > 0 && $model_end > 0)
{

open(IN,"$ARGV[0]");
@indata = <IN>;$i=1;
close IN;

foreach $line(@indata) {
 if($line =~ /^MODEL/) {$file="$ARGV[0]";open(OUT,">$file");next}
 if($line =~ /^ENDMDL/) {next}
 if($line =~ /^ATOM/ || $line =~ /^HETATM/) {print OUT "$line"}
 }
close OUT;
}
