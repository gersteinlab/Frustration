#usage perl RemoveTerminalGlys.pl PdbFile
my $PDB=$ARGV[0];

open (PDB, "$ARGV[0]");
my @PDB_File=<PDB>;
close PDB;

open (SALIDA, ">$ARGV[0]_aux_gly.txt");

for (my $i=0; $i<@PDB_File; $i++)
{

		my $RES=substr($PDB_File[$i], 17, 3);

		if($RES eq 'GLY')
		{
			next;
		}
		else
		{
			print SALIDA $PDB_File[$i];
		}

}

close SALIDA;

system ("mv $ARGV[0]_aux_gly.txt $ARGV[0]");
