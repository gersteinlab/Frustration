#!/usr/local/bin/perl
use strict;

my @equivalences=qx(awk '{print}' $ARGV[1]);

my %res_chain=();
my %res_eq=();

for (my $i=0; $i<@equivalences; $i++)
{
#I need to trim spaces in order to modify minmax, cont and res
my $aux_res=substr($equivalences[$i], 1,4); $aux_res =~ s/^\s+//;
my $aux_chain=substr($equivalences[$i], 0,1); 
my $aux_eq=substr($equivalences[$i], 5,5); $aux_eq =~ s/^\s+//; chomp ($aux_eq);

$res_chain{$aux_res}=$aux_chain;
$res_eq{$aux_res}=$aux_eq;

#print $aux_res, " $aux_chain $aux_eq\n";
}

#RENUM the minmax
open (MINMAX, "$ARGV[0]_minmax.dat");
my @MINMAX=<MINMAX>;
close MINMAX;

open (MINMAX_RENUM, ">$ARGV[0]_minmax_renum.dat");


foreach my $minmax_line (@MINMAX)
{
chomp ($minmax_line);
my @splited=split("\t", $minmax_line);
print MINMAX_RENUM "$res_eq{$splited[0]}\t$res_eq{$splited[1]}\t$splited[2]\t$splited[3]\t$splited[4]\t$splited[5]\t$res_chain{$splited[0]}\t$res_chain{$splited[1]}\n";
}
close MINMAX_RENUM;

#RENUM the cont
open (CONT, "$ARGV[0]_cont");
my @CONT=<CONT>;
close CONT;

open (CONT_RENUM, ">$ARGV[0]_cont_renum");

foreach my $cont_line (@CONT)
{
#print $cont_line;
chomp ($cont_line);
my @splited=split("\t", $cont_line);
print CONT_RENUM "$res_eq{$splited[0]}\t$res_eq{$splited[1]}\t$splited[2]\t$splited[3]\t$splited[4]\t$splited[5]\t$splited[6]\t$splited[7]\t$splited[8]\t$splited[9]\t$res_chain{$splited[0]}\t$res_chain{$splited[1]}\n";
}
close CONT_RENUM;



#RENUM the res
open (RES, "$ARGV[0]_res");
my @RES=<RES>;
close RES;

open (RES_RENUM, ">$ARGV[0]_res_renum");

foreach my $res_line (@RES)
{
chomp ($res_line);
my @splited=split("\t", $res_line);
print RES_RENUM "$res_eq{$splited[0]}\t$splited[1]\t$splited[2]\t$splited[3]\t$splited[4]\t$res_chain{$splited[0]}\n";
}
close RES_RENUM;

#RENUM the mutational

open (MUTATIONAL, "$ARGV[0]_mutational");
my @MUTATIONAL=<MUTATIONAL>;
close MUTATIONAL;

open (MUTATIONAL_RENUM, ">$ARGV[0]_mutational_renum");

foreach my $mutational_line (@MUTATIONAL)
{
		chomp ($mutational_line);
		my @splited=split("\t", $mutational_line);
		if($splited[0] =~ /PERRES/)
		{
				print MUTATIONAL_RENUM "$splited[0]\t$res_eq{$splited[1]}\t$splited[2]\t$splited[3]\t$splited[4]\t$splited[5]\t$splited[6]\n";
		}
		elsif($splited[0] eq "CONT_BOTH")
		{
				print MUTATIONAL_RENUM "$splited[0]\t$res_eq{$splited[1]}\t$res_eq{$splited[2]}\t$splited[3]\t$splited[4]\t$splited[5]\t$splited[6]\t$splited[7]\n";
		}
		else
		{
				print MUTATIONAL_RENUM "$splited[0]\t$res_eq{$splited[1]}\t$res_eq{$splited[2]}\t$splited[3]\t$splited[4]\t$splited[5]\t$splited[6]\n";
		}

}
close MUTATIONAL_RENUM;

#RENUM the config
open (CONFIG, "$ARGV[0]_config");
my @CONFIG=<CONFIG>;
close CONFIG;

open (CONFIG_RENUM, ">$ARGV[0]_config_renum");

foreach my $config_line (@CONFIG)
{
		chomp ($config_line);
		my @splited=split("\t", $config_line);

		if($splited[0] =~ /PERRES/)
		{
				print CONFIG_RENUM "$splited[0]\t$res_eq{$splited[1]}\t$splited[2]\t$splited[3]\t$splited[4]\n";
		}
		else
		{
				print CONFIG_RENUM "$splited[0]\t$res_eq{$splited[1]}\t$res_eq{$splited[2]}\t$splited[3]\t$splited[4]\t$splited[5]\t$splited[6]\t$splited[7]\t$splited[8]\t$splited[9]\t$splited[10]\n";
		}

}
close CONFIG_RENUM;


#RENUM the PDB

open (PDB, "$ARGV[0]");
my @PDB=<PDB>;
close PDB;

open (PDB_RENUM, ">$ARGV[2].done/renum_$ARGV[2]");

foreach my $pdb_line (@PDB)
{



my $begin=substr($pdb_line, 0, 22);
my $to_convert=substr($pdb_line,22,4); $to_convert =~ s/^\s+//;
$to_convert--;

my $converted=$res_eq{$to_convert};



my $end="";


if($converted<10){$converted="   ".$converted;} elsif($converted<100){$converted="  ".$converted;}elsif($converted<1000){$converted=" ".$converted;}

#my @aux=split('', $converted);
#my $converted_tam=@aux;
#print $converted_tam,"\n";
if(length($converted) == 4)
{
$end=substr($pdb_line, 26);
}
else
{
$end=substr($pdb_line, 27);
}


#print "$to_convert -- > $converted\n";

print PDB_RENUM $begin,$converted,$end;
}
close PDB_RENUM;

