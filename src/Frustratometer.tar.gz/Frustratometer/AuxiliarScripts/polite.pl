#!/usr/bin/perl
use strict;

print "$ARGV[0]\n";

my $Res_File=$ARGV[0];
my $Cont_File=$ARGV[1];
my $path=$ARGV[2];

open (CONT, "$path/$Cont_File");
my @cont=<CONT>;
close CONT;

open (RES, "$path/$Res_File");
my @res=<RES>;
close RES;

my %Aminoacids=();

$Aminoacids{'0'}='A';
$Aminoacids{'1'}='R';
$Aminoacids{'2'}='N';
$Aminoacids{'3'}='D';
$Aminoacids{'4'}='C';
$Aminoacids{'5'}='Q';
$Aminoacids{'6'}='E';
$Aminoacids{'7'}='G';
$Aminoacids{'8'}='H';
$Aminoacids{'9'}='I';
$Aminoacids{'10'}='L';
$Aminoacids{'11'}='K';
$Aminoacids{'12'}='M';
$Aminoacids{'13'}='F';
$Aminoacids{'14'}='P';
$Aminoacids{'15'}='S';
$Aminoacids{'16'}='T';
$Aminoacids{'17'}='W';
$Aminoacids{'18'}='Y';
$Aminoacids{'19'}='V';

my %types=();

$types{'1'}="short";
$types{'2'}="long";
$types{'3'}="water_mediated";

open (CONT, ">$path/$Cont_File");
print CONT "#residue1\tresidue2\tconfigurational-frustration-index\tmutational-frustration-index\taminoacid-type1\taminoacid-type2\tresidue1_sasa\tresidue2_sasa	welltype\n";

foreach my $line (@cont)
{
my $modified_line=();
if ($line !~ /#/)
{
my @splited_line = split ('\t', $line);
$splited_line[4]=$Aminoacids{$splited_line[4]};
$splited_line[5]=$Aminoacids{$splited_line[5]};

$splited_line[8]=$types{$splited_line[8]};
$splited_line[9]=$types{$splited_line[9]};

$modified_line = join("\t", @splited_line);

}

print CONT "$modified_line";
#print "$modified_line\n";
}

close CONT;

open (RES, ">$path/$Res_File");
print RES "#residue_number\tburial-frustration_index\tsingle_residue_level-frustration_index\taminoacid-type\tresidue_sasa\n";
foreach my $line (@res)
{
my $modified_line=();
if ($line !~ /#/)
{
my @splited_line = split ('\t', $line);
$splited_line[3]=$Aminoacids{$splited_line[3]};

$modified_line = join("\t", @splited_line);

}

print RES "$modified_line";

}

close RES;


