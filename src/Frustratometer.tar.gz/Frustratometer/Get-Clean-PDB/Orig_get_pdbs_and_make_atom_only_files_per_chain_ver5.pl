#!/usr/local/bin/perl

#ver5	like ver2 but adds the ability to pull the pdb files from local directory - that way they can be modified before (ie remove unwanted aa's, etc)
#ver5	also modified to convert MSE to MET (and convert atom name 'SE' for Se to 'SD' for S at D position)
#ver2	adds a flag so that the user can choose to not save the ent (coord ATOM record) file 
#ver2	also, I removed the conversion of the chain id to uppercase since some chain ids are lower case
#ver2	also, if there is no chain id in the pdb file, i report both files as xxxx_ (without a chain id since 0 is a valid chain id)
#
#this will grab pdb structures via FTP based on a list of ntrn1-formatted ids
#it will then extract the ATOM records that correspond to the specific protein chain and create a new file
#when multiple MODELS exist (NMR structure, for example), it will extract the first model

#this script also takes care of the pos 27 in ATOM record: residue insersion code (this occurs when additional residues
#are found in a protein relative to an aligned one). In this situation, the depositor has the option to hold the residue
#number constant and iterate the insersion id.

use Net::FTP;

# Check the command line
#if ($#ARGV != 1) {  die ("USAGE: .pl <protein-list-filename> <output directory>\n"); }

#get the pdbs from the remove ftp server (pdb server)
$get_pdbs_remotely=0;
$local_pdb_dir = "pdbs";
#set keep_chain_coord_file to 1 to keep the ent file with ATOM record for the specified chain
$keep_chain_coord_file = 1;
#$renumber is an adjustable flag. Set to 1 if I want to renumber pdb files so the first residue present is 1.
#set to 0 otherwise
$renumber = 1;
#$remove_alts is an adjustable flag. Set to 1 if I want to remove atoms annotated with alternate location indicators
#that is, I will keep only the first atom position indicated for each atom type on each residue (this is pos 17 in pdb ATOM rec)
$remove_alts = 1;

%one_code = (   'ALA','A',
                'CYS','C',
                'ASP','D',
                'GLU','E',
                'PHE','F',
                'GLY','G',
                'HIS','H',
                'ILE','I',
                'LYS','K',
                'LEU','L',
                'MET','M',
                'ASN','N',
                'PRO','P',
                'GLN','Q',
                'ARG','R',
                'SER','S',
                'THR','T',
                'VAL','V',
                'TRP','W',
                'TYR','Y');


# Read the lines in input file into @list
open (LIST, "$ARGV[0]"); 

while (<LIST>) 
{ 
	chop(); 
	#set column that contains residue number
	$ntrn1_name = $_;
	$new_protein_name = $_;
	
        if ($_ !~ /_$/) 
        {
	        $letter = chop ($new_protein_name);
	        #$letter = lc $letter_temp;
	} 
        else 
        {
	        $letter = "_";
	        #$letter = "0";
	}
	chop($new_protein_name);

	@list_name = (@list_name, $new_protein_name); 
	#@list_letter = (@list_letter, lc $letter); 
	@list_letter = (@list_letter, $letter); 
	@ntrn1_names = (@ntrn1_names, $ntrn1_name); 
} 
close (LIST);

print "1\n";

# Create the output directory if it does not already exist
if (! -d $ARGV[1]) { mkdir $ARGV[1], 0755 || die "Unable to create output directory"; }

$pdb_extension = ".ent.Z";
$count_protein = 0;

foreach $protein (@list_name) {
 $count_protein++;

 #print "DOLIN\t".$protein."\t".$list_letter[$count_protein-1]."\n";
  #print ".";

# chop ($protein);

 $file_to_ftp = "pdb$protein$pdb_extension";
	
 $pdb_filename = "pdb$protein.ent";

 if ($get_pdbs_remotely==1) {
   #this will open the PDB from the remote source (via FTP)
   $ftp = Net::FTP->new("ftp.rcsb.org", Debug=> 0);
   $ftp->login("anonymous",'jhegler@chem.ucsd.edu');
   $ftp->cwd("/pub/pdb/data/structures/all/pdb");
   #print $file_to_ftp."\t".$protein."\t".$list_letter[$count_protein-1]."\n";
   if (defined($ftp->get("$file_to_ftp"))) {
     system "mv $file_to_ftp $ARGV[1]" || print "can\'t move $file_to_ftp, $!";
     system "gunzip $ARGV[1]/$file_to_ftp" || print "can\'t gunzip $file_to_ftp, $!";
     open (TEMP,"$ARGV[1]/$pdb_filename"); @temp_array = (); @temp_array=<TEMP>; close (TEMP);
     $flag = 0;
     $zero_chain_id_found = 0; #we assume there is no chain id of 'zero'
     foreach $temp_line (@temp_array) {
	if (($temp_line =~ /^MODEL        2 /)||($temp_line =~ /^MODEL        2$/)) { $flag = 1; }
	if (($temp_line =~ /^MODEL       2 /)||($temp_line =~ /^MODEL       2$/)) { $flag = 2; }
	if ($temp_line =~ /^ATOM /) {
	    @atom_parts = split (//,$temp_line);
	    if ($atom_parts[21] eq '0') { $zero_chain_id_found=1; }
	}
     }
   }
   else { print "\ncan't get file".$file_to_ftp."\n"; }
 }
 else {
   #this will open the PDB locally
     open (TEMP,"$local_pdb_dir/$pdb_filename"); @temp_array = (); @temp_array=<TEMP>; close (TEMP);
     $flag = 0;
     $zero_chain_id_found = 0; #we assume there is no chain id of 'zero'
     foreach $temp_line (@temp_array) {
	if (($temp_line =~ /^MODEL        2 /)||($temp_line =~ /^MODEL        2$/)) { $flag = 1; }
	if (($temp_line =~ /^MODEL       2 /)||($temp_line =~ /^MODEL       2$/)) { $flag = 2; }
	if ($temp_line =~ /^ATOM /) {
	    @atom_parts = split (//,$temp_line);
	    if ($atom_parts[21] eq '0') { $zero_chain_id_found=1; }
	}
     }
     #system "cp $local_pdb_dir/$pdb_filename $ARGV[1]" || print "can\'t move $file_to_ftp, $!";
     system "cp ./$local_pdb_dir/$pdb_filename ./output"; 
 }

	print $flag."\n";
   #$list_letter_uc = uc $list_letter[$count_protein-1];
   #if ($list_letter[$count_protein-1] ne "_") {
   if (($list_letter[$count_protein-1] ne "_")&&(($list_letter[$count_protein-1] ne "0")||($zero_chain_id_found == 1))) {
     #print "grep \"ATOM\" $ARGV[1]/$pdb_filename | awk '(\$5 eq $list_letter[$count_protein-1]){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1]";
     #print "grep -B 1000 \"^MODEL \" $ARGV[1]/$pdb_filename | grep \"^ATOM \" | awk '(\$5 eq $list_letter[$count_protein-1]){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent";
     if ($flag == 1) {
	#system "grep -B 1000000 \"^MODEL        2\" $ARGV[1]/$pdb_filename | grep \"^ATOM \" | awk -F \"\" '(\$22 \=\= \"$list_letter[$count_protein-1]\"){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
	system "perl -pe 's/HETATM(.*)SE (.*)MSE/ATOM  \\1 SD\\2MET/' $ARGV[1]/$pdb_filename | perl -pe 's/HETATM(.*)MSE/ATOM  \\1MET/' | grep -B 1000000 \"^MODEL        2\" | grep \"^ATOM \" | awk -F \"\" '(\$22 \=\= \"$list_letter[$count_protein-1]\"){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
     }
     elsif ($flag == 2) {
	#system "grep -B 1000000 \"^MODEL       2\" $ARGV[1]/$pdb_filename | grep \"^ATOM \" | awk -F \"\" '(\$22 \=\= \"$list_letter[$count_protein-1]\"){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
	system "perl -pe 's/HETATM(.*)SE (.*)MSE/ATOM  \\1 SD\\2MET/' $ARGV[1]/$pdb_filename | perl -pe 's/HETATM(.*)MSE/ATOM  \\1MET/' | grep -B 1000000 \"^MODEL       2\" | grep \"^ATOM \" | awk -F \"\" '(\$22 \=\= \"$list_letter[$count_protein-1]\"){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
     }
     else {
	#system "grep \"^ATOM \" $ARGV[1]/$pdb_filename | awk -F \"\" '(\$22 \=\= \"$list_letter[$count_protein-1]\"){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
	system "perl -pe 's/HETATM(.*)SE (.*)MSE/ATOM  \\1 SD\\2MET/' $ARGV[1]/$pdb_filename | perl -pe 's/HETATM(.*)MSE/ATOM  \\1MET/' | grep \"^ATOM \" | awk -F \"\" '(\$22 \=\= \"$list_letter[$count_protein-1]\"){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
	#print "grep \"^ATOM \" $ARGV[1]/$pdb_filename | awk -F \"\" '(\$22 \=\= \"$list_letter_uc\"){print}' > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
     }
   }
   elsif (($list_letter[$count_protein-1] eq "_")||(($list_letter[$count_protein-1] eq "0"))&&($zero_chain_id_found==0)) {
     #$list_letter[$count_protein-1] = 0;
     $list_letter[$count_protein-1] = "";
     #print "grep -B 1000 \"^MODEL \" $ARGV[1]/$pdb_filename | grep \"^ATOM \" > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent";
     if ($flag == 1) {
	#system "grep -B 1000000 \"^MODEL        2\" $ARGV[1]/$pdb_filename | grep \"^ATOM \" > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
	system "perl -pe 's/HETATM(.*)SE (.*)MSE/ATOM  \\1 SD\\2MET/' $ARGV[1]/$pdb_filename | perl -pe 's/HETATM(.*)MSE/ATOM  \\1MET/' | grep -B 1000000 \"^MODEL        2\" | grep \"^ATOM \" > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
     }
     elsif ($flag == 2) {
	#system "grep -B 1000000 \"^MODEL       2\" $ARGV[1]/$pdb_filename | grep \"^ATOM \" > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
	system "perl -pe 's/HETATM(.*)SE (.*)MSE/ATOM  \\1 SD\\2MET/' $ARGV[1]/$pdb_filename | perl -pe 's/HETATM(.*)MSE/ATOM  \\1MET/' | grep -B 1000000 \"^MODEL       2\" | grep \"^ATOM \" > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
     }
     else {
	#system "grep \"^ATOM \" $ARGV[1]/$pdb_filename > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
	system "perl -pe 's/HETATM(.*)SE (.*)MSE/ATOM  \\1 SD\\2MET/' $ARGV[1]/$pdb_filename | perl -pe 's/HETATM(.*)MSE/ATOM  \\1MET/' | grep \"^ATOM \" > $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp";
     }
   }
   else { print "Something is probably wrong with this one's chain id!\n"; }

   #system "rm $ARGV[1]/$pdb_filename" || print "can\'t del $pdb_filename, $!";
   system "rm ./output/$pdb_filename" || print "can\'t del $pdb_filename, $!";

   #here, i re-open the new file and extract the sequence based on the annotation of the CA atoms
   open (TEMP2,"$ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp") || print "WHAT??\n"; @temp_array = (); @temp_array=<TEMP2>; close (TEMP2);
   system "rm $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent_temp" || print "can\'t del thing, $!";
   $count=0;
   $count_ca=0;
   $count_res=1;
   $correct_seq_num=0;
   @sequence=();
   $new_pdb_flnm = $ARGV[1]."/pdb".$protein."_".$list_letter[$count_protein-1].".ent";
   if ($renumber) { open (NEWPDB,">$new_pdb_flnm") || print "WHAT??\n"; }
   #if ($renumber) { open (NEWPDB,">$ARGV[1]/pdb$protein_$list_letter[$count_protein-1].ent") || print "WHAT??\n"; }
   foreach $temp_line (@temp_array) {
	#here, i pull the position of the first res. If it is NOT 1, i renumber all residue so they start at one and go from there
	if ($renumber) {
		$res_pos = substr($temp_line,22,4); $res_pos =~ s/ //g;
		$insersion_code = substr($temp_line,26,1);
		if ($count==0) { $current_position=$res_pos; $current_ins_code=$insersion_code; $count++; }
		if (($res_pos == $current_position)&&($insersion_code eq $current_ins_code)) {}
		else { $count_res++; $current_position = $res_pos; $current_ins_code = $insersion_code; }
#print $res_pos."\t".$insersion_code."\t".$current_ins_code."\t".$count_res."\n";
		@parts = split (//,$temp_line); $parts[22]=" "; $parts[23]=" "; $parts[24]=" "; $parts[25]=" "; $parts[26]=" ";
		if ($count_res<10) { $parts[25]=$count_res; } elsif ($count_res<100) { @number = split (//,$count_res); $parts[24]=$number[0]; $parts[25]=$number[1]; } elsif ($count_res<1000) { @number = split (//,$count_res); $parts[23]=$number[0]; $parts[24]=$number[1]; $parts[25]=$number[2]; } elsif ($count_res<10000) { @number = split (//,$count_res); $parts[22]=$number[0]; $parts[23]=$number[1]; $parts[24]=$number[2]; $parts[25]=$number[3]; }
		if (($remove_alts)&&($parts[16] ne " ")) {
			if (($parts[16]eq"A")||($parts[16]eq"1")) {
				$parts[16]=" ";
				foreach $part (@parts) { print NEWPDB $part; } print NEWPDB;
			}
		}
		else {
			foreach $part (@parts) { print NEWPDB $part; } print NEWPDB;
		}
	}
	$atom_type = substr($temp_line,12,4);
	$atom_type =~ s/ //g;
	if ($atom_type eq "CA") { $count_ca++; @sequence = (@sequence, $one_code{substr($temp_line,17,3)}) }; 
   }
   if ($renumber) { close (NEWPDB); }
   if ($keep_chain_coord_file==0) { system "rm $ARGV[1]/pdb$protein$list_letter[$count_protein-1].ent" || print "can\'t del atom coord file, $!"; }
   $fasta_flnm = ">".$ARGV[1]."/".$protein."_".$list_letter[$count_protein-1].".fasta";
   #open (FASTA,">$ARGV[1]/$protein$list_letter[$count_protein-1].fasta");
   open (FASTA,"$fasta_flnm");
   print FASTA ">$protein$list_letter[$count_protein-1] mol:protein length:$count_ca\n";
   #open (FASTA,">$ARGV[1]/$ntrn1_names[$count_protein-1].fasta");
   #print FASTA ">$ntrn1_names[$count_protein-1] mol:protein length:$count_ca\n";
   $count=0;
   foreach $res (@sequence) { $count++; print FASTA $res; if ($count%40==0) {print FASTA "\n"; } }
   close (FASTA);

 if ($get_pdbs_remotely==1) { $ftp->quit; }
 
}

print $count_protein."\n";

